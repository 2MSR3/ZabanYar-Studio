import os
import tempfile
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

app = FastAPI(title="ZabanYar Studio MVP")
BASE = Path(__file__).parent
MODEL_NAME = os.getenv("WHISPER_MODEL", "small")

@app.get("/api/health")
def health():
    return {"ok": True, "transcription": "faster-whisper", "model": MODEL_NAME}

@app.post("/api/transcribe")
async def transcribe(file: UploadFile = File(...)):
    name = (file.filename or "video").replace("/", "_").replace("\\", "_")
    suffix = Path(name).suffix or ".mp4"
    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            tmp_path = tmp.name
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                tmp.write(chunk)

        from faster_whisper import WhisperModel
        model = WhisperModel(MODEL_NAME, device="cpu", compute_type="int8")
        segments, info = model.transcribe(
            tmp_path,
            beam_size=5,
            vad_filter=True,
            word_timestamps=False
        )
        results = []
        for i, seg in enumerate(segments):
            results.append({
                "id": i + 1,
                "start": round(float(seg.start), 3),
                "end": round(float(seg.end), 3),
                "text": seg.text.strip(),
                "speaker": None
            })
        return {
            "language": info.language,
            "language_probability": round(float(info.language_probability), 3),
            "segments": results,
            "note": "Speaker diarization is not enabled in this MVP."
        }
    except ImportError:
        raise HTTPException(status_code=503, detail="faster-whisper is not installed. Install requirements.txt.")
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Transcription failed: {str(exc)}")
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass

app.mount("/static", StaticFiles(directory=BASE / "static"), name="static")

@app.get("/")
def index():
    return FileResponse(BASE / "static" / "index.html")
